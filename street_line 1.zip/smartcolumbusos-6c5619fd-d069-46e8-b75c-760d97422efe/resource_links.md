## Resource links in dataset 

Listed below are useful links in this dataset : 

* Link(http://ogrip-geohio.opendata.arcgis.com/datasets/ff0af920c18e4aa78459137b6efcd3d3_18)
* Link(https://mapping.dublin.oh.us/arcgis/rest/services/Boundaries/MapServer/18)
